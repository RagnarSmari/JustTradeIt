
Just Trade It - Ragnar Smári Ó



Ran a Postman Script and got passed on everything but update profile but when I ran the update profile 
tests individually, the request went through.

You can make the same items over and over again in this API.
You can make the same trades over and over again in this API.

This API includes a notification service which sends an email
each time when there is made a new trade request or a trade request is updated.


All images in the program are uploaded to Amazon service bucket

Link to the bucket: 
	https://s3.console.aws.amazon.com/s3/buckets/raggistradebucket?region=eu-west-1&tab=objects








